for num in range(1000, 2000):
    if num % 11 == 5:
        print(num)
